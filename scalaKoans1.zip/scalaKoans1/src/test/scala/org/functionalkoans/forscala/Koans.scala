package org.functionalkoans.forscala

import org.scalatest._
import support.Master

class Koans extends Suite {
  override def nestedSuites = List(
    new AboutClasses,
    new AboutCaseClasses,
    new AboutObjects,
    new AboutTraits,
    new AboutSequencesAndArrays,
    new AboutLists,
    new AboutMaps,
    new AboutSets,
    new AboutMutableMaps,
    new AboutMutableSets,
    new AboutPatternMatching,
    new AboutForExpressions,
    new AboutParentClasses
    
    /*
    new AboutValAndVar,
    new AboutLiteralBooleans,
    new AboutLiteralNumbers,
    new AboutLiteralStrings,
    new AboutAsserts,
    new AboutRange,
    new AboutOptions,
    new AboutTuples,
    new AboutHigherOrderFunctions,
    new AboutPartiallyAppliedFunctions,
    new AboutFormatting,
    new AboutPartialFunctions,
    new AboutImplicits,
    new AboutInfixPrefixAndPostfixOperators,
    new AboutInfixTypes,
    new AboutIterables,
    new AboutTraversables,
    new AboutNamedAndDefaultArguments,
    new AboutManifests,
    new AboutPreconditions,
    new AboutExtractors,
    new AboutByNameParameter,
    new AboutRepeatedParameters,
    new AboutEmptyValues,
    new AboutTypeSignatures,
    new AboutUniformAccessPrinciple,
    new AboutTypeVariance,
    new AboutEnumerations,
    new AboutConstructors
    */
  )

  override def run(testName: Option[String], reporter: Reporter, stopper: Stopper, filter: Filter,
                   configMap: Map[String, Any], distributor: Option[Distributor], tracker: Tracker) {
    super.run(testName, reporter, Master, filter, configMap, distributor, tracker)
  }

}
